import React from 'react';
import { Text, View } from 'react-native';
const CommanDetail =props =>{
    return <View><Text>Common</Text></View>
}

export default CommanDetail;