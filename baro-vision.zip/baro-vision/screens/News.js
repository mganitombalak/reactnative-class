import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';
import { Categories } from '../data/category-data';
const News = props => {
    const selectedCategoryId = props.navigation.getParam('categoryId');
    const category = Categories.find(x => x.id === selectedCategoryId);
    return (<View style={styles.screen}>
        <Text>{category.title}</Text>
        <Button title={"Go Back"} onPress={() => props.navigation.goBack()}></Button>
    </View>);
};

News.navigationOptions = navigationInfo => {
    let categoryId=navigationInfo.navigation.getParam('categoryId');
    let category= Categories.find(x => x.id === categoryId);
    return {
        headerTitle: category.title,
    };

};
const styles = StyleSheet.create({
    screen: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    }
});

export default News;