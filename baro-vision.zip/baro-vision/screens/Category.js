import React from 'react';
import { StyleSheet, FlatList,} from 'react-native';
import { Categories } from '../data/category-data';
import Tile from '../components/Tile';
const Category = props => {
    const listItemRenderer = itemData => {
        // props.navigation.navigate({routeName:'News',params:{categoryId:''}})
        return <Tile 
        title={itemData.item.title}
        color={itemData.item.color}
        onSelected={() => 
            { props.navigation.navigate('News', { categoryId: itemData.item.id }); }}/>;
    };
    // console.log(props);
    return (
        <FlatList data={Categories} numColumns={2} renderItem={listItemRenderer} />
        // <View style={styles.screen}>
        //     <Text>Category Screen is working!</Text>
        //     <Button title="Go News!" onPress={() => {
        //         props.navigation.navigate('News');//navigate({ routeName: 'News' })
        //     }}></Button>
        // </View>
    );
};
Category.navigationOptions={
    headerTitle:'Ana Sayfa',
};
const styles = StyleSheet.create({
    screen: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    }
});

export default Category;