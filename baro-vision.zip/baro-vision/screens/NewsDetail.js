import React from 'react';
import { Text, View } from 'react-native';
const NewsDetail =props =>{
    return <View><Text>Common</Text></View>
}

export default NewsDetail;