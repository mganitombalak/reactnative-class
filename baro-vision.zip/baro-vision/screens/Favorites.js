import React from 'react';
import { Text, View } from 'react-native';
const Favorites =props =>{
    return <View><Text>Favorites</Text></View>
}

export default Favorites;