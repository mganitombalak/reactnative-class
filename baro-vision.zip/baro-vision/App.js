import React, { useState } from 'react';
import * as FontUtil from 'expo-font';
import { AppLoading } from 'expo';
import MyStackNavigator from './navigation/nav';

const loadFonts = () => {
  return FontUtil.loadAsync({
    'nerko-one': require('./assets/fonts/NerkoOne-Regular.ttf'),
    'oswald-bold': require('./assets/fonts/Oswald-Bold.ttf')
  });
};

export default function App() {
  const [fontsLoaded, setFontsLoaded] = useState(false);

  if(!fontsLoaded){
    return <AppLoading startAsync={loadFonts} onFinish={()=>setFontsLoaded(true)}></AppLoading>
  }
  return (
    <MyStackNavigator/>
  );
}
