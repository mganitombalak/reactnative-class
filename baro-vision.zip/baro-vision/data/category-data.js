import Category from '../models/Category';

export const Categories=[
    new Category(1,"Haber",'#FF12BE'),
    new Category(2,"Baro",'#800000'),
    new Category(3,"Avukat",'#FFFF00'),
    new Category(4,"Dosya Takip",'#00FF00'),
    new Category(5,"Sozluk",'#00FFFF'),
    new Category(6,"E-Arzuhal",'#FF00FF')
];