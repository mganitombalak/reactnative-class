import Video from '../models/Video';

export const Videos=[
    new Video(262,"AYM ve AİHM’E Bireysel Başvuru Eğitimi",'https://www.youtube.com/embed/hgEHSKMILNw','Bireysel Başvuru','2019-04-19','İnsan Hakları Merkezi','https://www.istanbulbarosu.org.tr/files/barovizyon/videothumbs/hgEHSKMILNw.jpg'),
    new Video(263,"AYM ve AİHM’E Bireysel Başvuru Eğitimi",'https://www.youtube.com/embed/hgEHSKMILNw','Bireysel Başvuru','2019-04-19','İnsan Hakları Merkezi','https://www.istanbulbarosu.org.tr/files/barovizyon/videothumbs/hgEHSKMILNw.jpg'),
    new Video(264,"AYM ve AİHM’E Bireysel Başvuru Eğitimi",'https://www.youtube.com/embed/hgEHSKMILNw','Bireysel Başvuru','2019-04-19','İnsan Hakları Merkezi','https://www.istanbulbarosu.org.tr/files/barovizyon/videothumbs/hgEHSKMILNw.jpg')
];