export default {
    primary:'#F1EA0D',
    secondary:'#E400FF',
    red:'#FF0064',
    black:'#000000',
    white:'#FFF'
};