
class Video {
    constructor(id, title, videoUrl,categoryName,date,commissionName,thumbUrl) {
        this.id = id;
        this.title = title;
        this.videoUrl = videoUrl;
        this.categoryName = categoryName;
        this.date=date;
        this.commissionName=commissionName;
        this.thumbUrl=thumbUrl;

    }
}

export default Video;