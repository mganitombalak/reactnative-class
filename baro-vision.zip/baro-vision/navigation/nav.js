import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';
import CategoryScreen from '../screens/Category';
import NewsScreen from '../screens/News';
import { Platform } from 'react-native';
import Colors from '../constant/Colors';

const MyStackNavigator = createStackNavigator({
    Category: CategoryScreen,
    News: NewsScreen,
},
    {
        // initialRouteName:'News',
        // mode:'modal',
        defaultNavigationOptions: {
            headerStyle: {
                backgroundColor: Platform.OS === 'android' ? Colors.red : Colors.white
            },
            headerTintColor: Platform.OS === 'android' ? Colors.white : Colors.red
        }
    });

export default createAppContainer(MyStackNavigator);