export const SELECT_NEWS = 'SELECT_NEWS'

export const selectNews = newsItem => {
    return { type: SELECT_NEWS, payload: newsItem };
}