import { Videos } from '../../data/videos-data';
import { SELECT_NEWS } from '../action/news';
const initialState = {
    videos: Videos,
    selected: null
}

const NewsReducer = (state = initialState, action) => {
    switch (action.type) {
        case SELECT_NEWS:
            return {...state,selected:action.payload};
        default:
            return state;
    }
}

export default NewsReducer