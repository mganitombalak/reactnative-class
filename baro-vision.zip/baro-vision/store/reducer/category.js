import {Categories} from '../../data/category-data';

const initialState = {
    categories: Categories
}

const CategoryReducer = (state = initialState, action) => {
    return state;
}

export default CategoryReducer